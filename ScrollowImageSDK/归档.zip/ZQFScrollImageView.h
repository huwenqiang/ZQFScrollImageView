//
//  ZQFScrollowImage.h
//  ScrollowImageSDK
//
//  Created by zengqingfu on 14/12/27.
//  Copyright (c) 2014年 zengqingfu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZQFScrollImageView : UIView

@property(nonatomic, strong, readwrite) NSArray *images;
@property(nonatomic, assign, readonly)  NSInteger currentPage;

@property(nonatomic, assign, readwrite)NSTimeInterval timerInterval;

- (id)initWithFrame:(CGRect)frame;
- (void)clickAction:(void (^)(NSInteger pageIndex))click;
- (void)start;
- (void)stop;

@end
